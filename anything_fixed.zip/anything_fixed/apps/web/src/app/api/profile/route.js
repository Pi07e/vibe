import sql from "@/app/api/utils/sql";
import { auth } from "@/auth";

export async function POST(request) {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const body = await request.json();
    const { username } = body || {};

    if (
      !username ||
      typeof username !== "string" ||
      username.trim().length === 0
    ) {
      return Response.json({ error: "Username is required" }, { status: 400 });
    }

    // Check if username already exists in users_profiles
    const existingProfiles = await sql`
      SELECT id FROM users_profiles WHERE username = ${username.trim()} LIMIT 1
    `;

    if (existingProfiles.length > 0) {
      return Response.json(
        { error: "Username already taken" },
        { status: 400 },
      );
    }

    // Create user profile linked to auth user
    const profile = await sql`
      INSERT INTO users_profiles (id, username, full_name, avatar_url)
      VALUES (${userId}, ${username.trim()}, ${session.user.name || null}, ${session.user.image || null})
      ON CONFLICT (id) DO UPDATE 
      SET username = ${username.trim()},
          full_name = ${session.user.name || null},
          avatar_url = ${session.user.image || null}
      RETURNING id, username, full_name, avatar_url
    `;

    return Response.json({ profile: profile[0] });
  } catch (err) {
    console.error("POST /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}

export async function GET() {
  try {
    const session = await auth();
    if (!session || !session.user?.id) {
      return Response.json({ error: "Unauthorized" }, { status: 401 });
    }

    const userId = session.user.id;
    const profiles = await sql`
      SELECT id, username, full_name, avatar_url, phone_number, created_at
      FROM users_profiles
      WHERE id = ${userId}
      LIMIT 1
    `;

    const profile = profiles?.[0] || null;
    return Response.json({ profile });
  } catch (err) {
    console.error("GET /api/profile error", err);
    return Response.json({ error: "Internal Server Error" }, { status: 500 });
  }
}
