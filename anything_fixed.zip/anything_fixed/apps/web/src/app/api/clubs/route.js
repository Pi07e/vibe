import sql from "@/app/api/utils/sql";

export async function GET() {
  try {
    const clubs = await sql`SELECT * FROM clubs ORDER BY name ASC`;
    return Response.json(clubs);
  } catch (error) {
    console.error("Error fetching clubs:", error);
    return Response.json({ error: "Failed to fetch clubs" }, { status: 500 });
  }
}
