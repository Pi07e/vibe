import sql from "@/app/api/utils/sql";

export async function POST(request) {
  try {
    const { userId, eventId, status } = await request.json();

    if (!userId || !eventId || !status) {
      return Response.json(
        { error: "Missing required fields" },
        { status: 400 },
      );
    }

    await sql`
      INSERT INTO event_responses (user_id, event_id, status)
      VALUES (${userId}, ${eventId}, ${status})
      ON CONFLICT (user_id, event_id)
      DO UPDATE SET status = ${status}, created_at = CURRENT_TIMESTAMP
    `;

    return Response.json({ success: true });
  } catch (error) {
    console.error("Error saving event response:", error);
    return Response.json({ error: "Failed to save response" }, { status: 500 });
  }
}
