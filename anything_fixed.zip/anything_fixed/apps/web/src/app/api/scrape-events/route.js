import sql from "@/app/api/utils/sql";

/**
 * Vienna Event Scraper — Ticketmaster implementation v2
 *
 * Pulls upcoming Vienna events from Ticketmaster Discovery API,
 * normalizes them, maps venues to known Vienna clubs, and upserts
 * into the events table. Safe to run on a cron every 6-12 hours.
 *
 * Requires env var: TICKETMASTER_API_KEY
 */

const TICKETMASTER_BASE = "https://app.ticketmaster.com/discovery/v2/events.json";
const PAGE_SIZE = 100;

export async function POST() {
  if (!process.env.TICKETMASTER_API_KEY) {
    return Response.json(
      { error: "TICKETMASTER_API_KEY not configured" },
      { status: 500 },
    );
  }

  try {
    // Load all known clubs once so we can map venues to club_id
    const clubs = await sql`SELECT id, name FROM clubs`;
    const clubNameToId = new Map(
      clubs.map((c) => [normalizeClubName(c.name), c.id]),
    );

    const tmEvents = await fetchAllTicketmasterEvents();
    const normalized = tmEvents
      .map((tm) => normalizeEvent(tm, clubNameToId))
      .filter(Boolean);

    let insertedCount = 0;
    let updatedCount = 0;
    const errors = [];

    for (const event of normalized) {
      try {
        const result = await sql`
          INSERT INTO events (
            external_id, club_id, title, description, start_time, end_time,
            genre, price, ticket_url, image_url,
            location_name, latitude, longitude
          )
          VALUES (
            ${event.external_id}, ${event.club_id}, ${event.title}, ${event.description},
            ${event.start_time}, ${event.end_time}, ${event.genre},
            ${event.price}, ${event.ticket_url}, ${event.image_url},
            ${event.location_name}, ${event.latitude}, ${event.longitude}
          )
          ON CONFLICT (external_id) DO UPDATE SET
            club_id = EXCLUDED.club_id,
            title = EXCLUDED.title,
            description = EXCLUDED.description,
            start_time = EXCLUDED.start_time,
            end_time = EXCLUDED.end_time,
            genre = EXCLUDED.genre,
            price = EXCLUDED.price,
            ticket_url = EXCLUDED.ticket_url,
            image_url = EXCLUDED.image_url,
            location_name = EXCLUDED.location_name,
            latitude = EXCLUDED.latitude,
            longitude = EXCLUDED.longitude
          RETURNING (xmax = 0) AS inserted
        `;
        if (result[0]?.inserted) {
          insertedCount++;
        } else {
          updatedCount++;
        }
      } catch (err) {
        console.error(`Failed to upsert event "${event.title}":`, err.message);
        errors.push({ title: event.title, error: err.message });
      }
    }

    return Response.json({
      success: true,
      scraped: tmEvents.length,
      inserted: insertedCount,
      updated: updatedCount,
      failed: errors.length,
      errors: errors.slice(0, 5),
    });
  } catch (error) {
    console.error("Scraping error:", error);
    return Response.json(
      { error: "Failed to scrape events", detail: error.message },
      { status: 500 },
    );
  }
}

async function fetchAllTicketmasterEvents() {
  const all = [];
  let page = 0;
  let totalPages = 1;

  while (page < totalPages) {
    const url = new URL(TICKETMASTER_BASE);
    url.searchParams.set("apikey", process.env.TICKETMASTER_API_KEY);
    url.searchParams.set("city", "Vienna");
    url.searchParams.set("countryCode", "AT");
    url.searchParams.set("size", String(PAGE_SIZE));
    url.searchParams.set("page", String(page));
    url.searchParams.set("sort", "date,asc");

    const response = await fetch(url.toString());
    if (!response.ok) {
      throw new Error(
        `Ticketmaster returned ${response.status}: ${await response.text()}`,
      );
    }

    const data = await response.json();
    const events = data._embedded?.events ?? [];
    all.push(...events);

    totalPages = data.page?.totalPages ?? 1;
    page++;

    if (page < totalPages) {
      await sleep(250);
    }
  }

  return all;
}

function normalizeEvent(tm, clubNameToId) {
  if (!tm.id || !tm.name) return null;

  const startDateTime =
    tm.dates?.start?.dateTime ||
    (tm.dates?.start?.localDate
      ? `${tm.dates.start.localDate}T${tm.dates.start.localTime || "20:00:00"}`
      : null);
  if (!startDateTime) return null;

  const venue = tm._embedded?.venues?.[0];
  const location_name = venue?.name || "Vienna";
  const latitude = venue?.location?.latitude
    ? parseFloat(venue.location.latitude)
    : null;
  const longitude = venue?.location?.longitude
    ? parseFloat(venue.location.longitude)
    : null;

  // Try to match the Ticketmaster venue to one of our known clubs
  const club_id = location_name
    ? clubNameToId.get(normalizeClubName(location_name)) ?? null
    : null;

  const image_url = pickBestImage(tm.images);

  const priceRange = tm.priceRanges?.[0];
  const price = priceRange?.min ?? null;

  const classification = tm.classifications?.[0];
  const genre =
    classification?.genre?.name && classification.genre.name !== "Undefined"
      ? classification.genre.name
      : classification?.segment?.name || "Other";

  return {
    external_id: `tm_${tm.id}`,
    club_id,
    title: tm.name,
    description: tm.info || tm.pleaseNote || null,
    start_time: new Date(startDateTime),
    end_time: tm.dates?.end?.dateTime ? new Date(tm.dates.end.dateTime) : null,
    genre,
    price,
    ticket_url: tm.url,
    image_url,
    location_name,
    latitude,
    longitude,
  };
}

/**
 * Normalize club name for matching.
 * Lowercase, trim, collapse whitespace, strip common suffixes.
 * So "Grelle Forelle" matches "GRELLE FORELLE" and "grelle forelle club".
 */
function normalizeClubName(name) {
  if (!name) return "";
  return name
    .toLowerCase()
    .trim()
    .replace(/\s+/g, " ")
    .replace(/\s+(club|music club|wien|vienna)$/i, "");
}

function pickBestImage(images) {
  if (!Array.isArray(images) || images.length === 0) return null;
  const landscape = images
    .filter((img) => img.ratio === "16_9")
    .sort((a, b) => (b.width || 0) - (a.width || 0));
  return landscape[0]?.url || images[0]?.url || null;
}

function sleep(ms) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}
