import sql from "@/app/api/utils/sql";

export async function GET(request) {
  const { searchParams } = new URL(request.url);
  const id = searchParams.get("id");
  const genre = searchParams.get("genre");
  const clubId = searchParams.get("clubId");
  const upcoming = searchParams.get("upcoming") === "true";

  try {
    let query = `
      SELECT e.*, c.name as club_name, c.address as club_address, c.district as club_district
      FROM events e
      LEFT JOIN clubs c ON e.club_id = c.id
      WHERE 1=1
    `;
    const params = [];

    if (id) {
      params.push(id);
      query += ` AND e.id = $${params.length}`;
    }

    if (genre) {
      params.push(genre);
      query += ` AND e.genre = $${params.length}`;
    }

    if (clubId) {
      params.push(clubId);
      query += ` AND e.club_id = $${params.length}`;
    }

    if (upcoming) {
      query += ` AND e.start_time >= NOW()`;
    }

    query += ` ORDER BY e.start_time ASC`;

    const events = await sql(query, params);
    return Response.json(events);
  } catch (error) {
    console.error("Error fetching events:", error);
    return Response.json({ error: "Failed to fetch events" }, { status: 500 });
  }
}
