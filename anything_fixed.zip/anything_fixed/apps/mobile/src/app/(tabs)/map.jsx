import React from "react";
import { View, Text, StyleSheet, TouchableOpacity } from "react-native";
import MapView, { Marker, Callout } from "react-native-maps";
import { useQuery } from "@tanstack/react-query";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useRouter } from "expo-router";
import { MapPin } from "lucide-react-native";

export default function MapScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const { data: events } = useQuery({
    queryKey: ["events-map"],
    queryFn: async () => {
      const response = await fetch("/api/events?upcoming=true");
      if (!response.ok) throw new Error("Network error");
      const data = await response.json();
      return Array.isArray(data) ? data : [];
    },
  });

  const eventList = Array.isArray(events) ? events : [];

  const INITIAL_REGION = {
    latitude: 48.2082,
    longitude: 16.3738,
    latitudeDelta: 0.0922,
    longitudeDelta: 0.0421,
  };

  return (
    <View style={{ flex: 1 }}>
      <MapView
        style={StyleSheet.absoluteFill}
        initialRegion={INITIAL_REGION}
        showsUserLocation
      >
        {events
          ?.filter((e) => e.latitude && e.longitude)
          .map((event) => (
            <Marker
              key={event.id}
              coordinate={{
                latitude: event.latitude,
                longitude: event.longitude,
              }}
            >
              <View
                style={{
                  backgroundColor: "#000",
                  padding: 8,
                  borderRadius: 20,
                  borderWidth: 2,
                  borderColor: "#fff",
                }}
              >
                <MapPin size={16} color="#fff" />
              </View>
              <Callout onPress={() => router.push(`/event/${event.id}`)}>
                <View style={{ padding: 10, width: 200 }}>
                  <Text style={{ fontWeight: "bold", fontSize: 16 }}>
                    {event.title}
                  </Text>
                  <Text style={{ color: "#666", fontSize: 12 }}>
                    {event.location_name || event.club_name}
                  </Text>
                  <Text
                    style={{
                      color: "#000",
                      fontSize: 12,
                      marginTop: 4,
                      fontWeight: "bold",
                    }}
                  >
                    Tap to view details
                  </Text>
                </View>
              </Callout>
            </Marker>
          ))}
      </MapView>

      {/* Search Overlay */}
      <View
        style={{
          position: "absolute",
          top: insets.top + 20,
          left: 20,
          right: 20,
          backgroundColor: "#fff",
          borderRadius: 25,
          padding: 15,
          flexDirection: "row",
          alignItems: "center",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 2 },
          shadowOpacity: 0.2,
          shadowRadius: 4,
          elevation: 5,
        }}
      >
        <Text style={{ color: "#666", fontSize: 16 }}>
          Search clubs or events in Vienna...
        </Text>
      </View>
    </View>
  );
}
