import React from "react";
import { View, Text, ScrollView, TouchableOpacity } from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  UserPlus,
  MessageCircle,
  ChevronRight,
  Search,
} from "lucide-react-native";

const MOCK_FRIENDS = [
  {
    id: "1",
    name: "Lena",
    avatar: "https://i.pravatar.cc/150?u=lena",
    status: "Going to Techno Tuesday",
  },
  {
    id: "2",
    name: "Matteo",
    avatar: "https://i.pravatar.cc/150?u=matteo",
    status: "Interested in Indie Night",
  },
  {
    id: "3",
    name: "Noah",
    avatar: "https://i.pravatar.cc/150?u=noah",
    status: "At Donauinsel",
  },
  {
    id: "4",
    name: "Sophie",
    avatar: "https://i.pravatar.cc/150?u=sophie",
    status: "Available for tonight",
  },
];

export default function FriendsScreen() {
  const insets = useSafeAreaInsets();

  return (
    <View style={{ flex: 1, backgroundColor: "#fff", paddingTop: insets.top }}>
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingVertical: 15,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <Text style={{ fontSize: 28, fontWeight: "bold", color: "#000" }}>
          Friends
        </Text>
        <TouchableOpacity
          style={{ padding: 10, backgroundColor: "#F3F4F6", borderRadius: 25 }}
        >
          <UserPlus size={20} color="#000" />
        </TouchableOpacity>
      </View>

      {/* Search */}
      <View style={{ paddingHorizontal: 20, marginBottom: 20 }}>
        <View
          style={{
            backgroundColor: "#F3F4F6",
            borderRadius: 12,
            padding: 12,
            flexDirection: "row",
            alignItems: "center",
          }}
        >
          <Search size={18} color="#666" style={{ marginRight: 10 }} />
          <Text style={{ color: "#666" }}>
            Find friends by username or phone
          </Text>
        </View>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 80,
        }}
      >
        <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 15 }}>
          Recent Activity
        </Text>

        {MOCK_FRIENDS.map((friend) => (
          <TouchableOpacity
            key={friend.id}
            style={{
              flexDirection: "row",
              alignItems: "center",
              backgroundColor: "#fff",
              padding: 15,
              borderRadius: 16,
              marginBottom: 12,
              borderWidth: 1,
              borderColor: "#F3F4F6",
            }}
          >
            <Image
              source={{ uri: friend.avatar }}
              style={{
                width: 50,
                height: 50,
                borderRadius: 25,
                marginRight: 15,
              }}
            />
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 16, fontWeight: "bold", color: "#000" }}>
                {friend.name}
              </Text>
              <Text style={{ fontSize: 14, color: "#666" }}>
                {friend.status}
              </Text>
            </View>
            <TouchableOpacity style={{ padding: 8 }}>
              <MessageCircle size={20} color="#000" />
            </TouchableOpacity>
          </TouchableOpacity>
        ))}

        {/* Suggestions */}
        <Text style={{ fontSize: 20, fontWeight: "bold", marginVertical: 15 }}>
          People you may know
        </Text>
        <ScrollView
          horizontal
          showsHorizontalScrollIndicator={false}
          style={{ flexGrow: 0 }}
        >
          {["Alex", "Ben", "Clara", "Daniel"].map((name, i) => (
            <View
              key={i}
              style={{
                width: 120,
                backgroundColor: "#F3F4F6",
                borderRadius: 16,
                padding: 15,
                alignItems: "center",
                marginRight: 12,
              }}
            >
              <Image
                source={{ uri: `https://i.pravatar.cc/150?u=${name}` }}
                style={{
                  width: 60,
                  height: 60,
                  borderRadius: 30,
                  marginBottom: 10,
                }}
              />
              <Text
                style={{ fontWeight: "bold", fontSize: 14, marginBottom: 8 }}
              >
                {name}
              </Text>
              <TouchableOpacity
                style={{
                  backgroundColor: "#000",
                  paddingHorizontal: 12,
                  paddingVertical: 6,
                  borderRadius: 8,
                }}
              >
                <Text
                  style={{ color: "#fff", fontSize: 12, fontWeight: "600" }}
                >
                  Add
                </Text>
              </TouchableOpacity>
            </View>
          ))}
        </ScrollView>
      </ScrollView>
    </View>
  );
}
