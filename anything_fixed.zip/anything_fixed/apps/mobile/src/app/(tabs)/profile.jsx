import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  ActivityIndicator,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { StatusBar } from "expo-status-bar";
import {
  Settings,
  LogOut,
  Ticket,
  Heart,
  Calendar,
  ChevronRight,
  Crown,
} from "lucide-react-native";
import { useAuth } from "@/utils/auth/useAuth";
import useSubscription from "@/utils/use-subscription";

export default function ProfileScreen() {
  const insets = useSafeAreaInsets();
  const { auth, isReady, signOut, signIn } = useAuth();
  const {
    isSubscribed,
    loading: subscriptionLoading,
    initiateSubscription,
  } = useSubscription();

  const handleSignOut = async () => {
    await signOut();
  };

  if (!isReady) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#fff",
          justifyContent: "center",
          alignItems: "center",
        }}
      >
        <ActivityIndicator size="large" color="#000" />
      </View>
    );
  }

  if (!auth || !auth.user) {
    return (
      <View
        style={{
          flex: 1,
          backgroundColor: "#fff",
          justifyContent: "center",
          alignItems: "center",
          padding: 20,
        }}
      >
        <StatusBar style="dark" />
        <Text style={{ fontSize: 24, fontWeight: "bold", marginBottom: 8 }}>
          Welcome to VieBe
        </Text>
        <Text
          style={{
            color: "#666",
            fontSize: 16,
            marginBottom: 20,
            textAlign: "center",
          }}
        >
          Sign in to save events, connect with friends, and unlock premium
          features
        </Text>
        <TouchableOpacity
          onPress={() => signIn()}
          style={{
            backgroundColor: "#000",
            paddingVertical: 14,
            paddingHorizontal: 32,
            borderRadius: 12,
          }}
        >
          <Text style={{ color: "#fff", fontSize: 16, fontWeight: "bold" }}>
            Sign In
          </Text>
        </TouchableOpacity>
      </View>
    );
  }

  const user = auth.user;

  const menuItems = [
    { icon: Ticket, label: "My Tickets", color: "#000" },
    { icon: Heart, label: "Saved Events", color: "#000" },
    { icon: Calendar, label: "Past Events", color: "#000" },
    { icon: Settings, label: "Settings", color: "#666" },
  ];

  return (
    <View style={{ flex: 1, backgroundColor: "#fff", paddingTop: insets.top }}>
      <StatusBar style="dark" />
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 80 }}
      >
        {/* Profile Header */}
        <View style={{ alignItems: "center", paddingVertical: 30 }}>
          <View style={{ position: "relative" }}>
            <Image
              source={{
                uri: user.image || `https://i.pravatar.cc/150?u=${user.email}`,
              }}
              style={{
                width: 120,
                height: 120,
                borderRadius: 60,
              }}
            />
            {isSubscribed && (
              <View
                style={{
                  position: "absolute",
                  bottom: 0,
                  right: 0,
                  backgroundColor: "#FFD700",
                  padding: 6,
                  borderRadius: 20,
                  borderWidth: 3,
                  borderColor: "#fff",
                }}
              >
                <Crown size={16} color="#000" />
              </View>
            )}
          </View>
          <Text
            style={{
              fontSize: 24,
              fontWeight: "bold",
              color: "#000",
              marginTop: 15,
            }}
          >
            {user.name || "User"}
          </Text>
          <Text style={{ fontSize: 16, color: "#666", marginTop: 5 }}>
            {user.email}
          </Text>
        </View>

        {/* Stats */}
        <View
          style={{
            flexDirection: "row",
            justifyContent: "space-around",
            paddingVertical: 20,
            borderBottomWidth: 1,
            borderBottomColor: "#F3F4F6",
          }}
        >
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 18, fontWeight: "bold" }}>24</Text>
            <Text style={{ fontSize: 12, color: "#666" }}>Events</Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 18, fontWeight: "bold" }}>142</Text>
            <Text style={{ fontSize: 12, color: "#666" }}>Friends</Text>
          </View>
          <View style={{ alignItems: "center" }}>
            <Text style={{ fontSize: 18, fontWeight: "bold" }}>8</Text>
            <Text style={{ fontSize: 12, color: "#666" }}>Clubs</Text>
          </View>
        </View>

        {/* Premium Card */}
        {subscriptionLoading ? (
          <View
            style={{
              marginHorizontal: 20,
              backgroundColor: "#F3F4F6",
              borderRadius: 20,
              padding: 20,
              marginBottom: 20,
              alignItems: "center",
            }}
          >
            <ActivityIndicator color="#000" />
          </View>
        ) : isSubscribed ? (
          <View
            style={{
              marginHorizontal: 20,
              backgroundColor: "#000",
              borderRadius: 20,
              padding: 20,
              marginBottom: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <Crown size={20} color="#FFD700" />
              <Text
                style={{
                  color: "#FFD700",
                  fontSize: 18,
                  fontWeight: "bold",
                  marginLeft: 8,
                }}
              >
                VieBe Premium Active
              </Text>
            </View>
            <Text style={{ color: "#ccc", fontSize: 14 }}>
              You have early access to tickets and exclusive guest lists.
            </Text>
          </View>
        ) : (
          <TouchableOpacity
            onPress={initiateSubscription}
            style={{
              marginHorizontal: 20,
              backgroundColor: "#000",
              borderRadius: 20,
              padding: 20,
              marginBottom: 20,
            }}
          >
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 5,
              }}
            >
              <Crown size={20} color="#FFD700" />
              <Text
                style={{
                  color: "#fff",
                  fontSize: 18,
                  fontWeight: "bold",
                  marginLeft: 8,
                }}
              >
                VieBe Premium
              </Text>
            </View>
            <Text style={{ color: "#ccc", fontSize: 14, marginBottom: 15 }}>
              Get early access to tickets and exclusive skip-the-line guest
              lists.
            </Text>
            <View
              style={{
                backgroundColor: "#fff",
                padding: 12,
                borderRadius: 12,
                alignItems: "center",
              }}
            >
              <Text style={{ color: "#000", fontWeight: "bold" }}>
                Upgrade for €5.99/month
              </Text>
            </View>
          </TouchableOpacity>
        )}

        {/* Menu Items */}
        <View style={{ padding: 20 }}>
          {menuItems.map((item, index) => (
            <TouchableOpacity
              key={index}
              style={{
                flexDirection: "row",
                alignItems: "center",
                paddingVertical: 18,
                borderBottomWidth: index === menuItems.length - 1 ? 0 : 1,
                borderBottomColor: "#F3F4F6",
              }}
            >
              <View
                style={{
                  backgroundColor: "#F3F4F6",
                  padding: 10,
                  borderRadius: 12,
                  marginRight: 15,
                }}
              >
                <item.icon size={20} color={item.color} />
              </View>
              <Text
                style={{
                  flex: 1,
                  fontSize: 16,
                  fontWeight: "600",
                  color: "#000",
                }}
              >
                {item.label}
              </Text>
              <ChevronRight size={20} color="#CCC" />
            </TouchableOpacity>
          ))}

          <TouchableOpacity
            onPress={handleSignOut}
            style={{
              flexDirection: "row",
              alignItems: "center",
              paddingVertical: 18,
              marginTop: 20,
            }}
          >
            <View
              style={{
                backgroundColor: "#FEE2E2",
                padding: 10,
                borderRadius: 12,
                marginRight: 15,
              }}
            >
              <LogOut size={20} color="#EF4444" />
            </View>
            <Text
              style={{
                flex: 1,
                fontSize: 16,
                fontWeight: "600",
                color: "#EF4444",
              }}
            >
              Sign Out
            </Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </View>
  );
}
