import React, { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  RefreshControl,
} from "react-native";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { useQuery } from "@tanstack/react-query";
import {
  Search,
  Filter,
  Calendar as CalendarIcon,
  MapPin,
  ChevronRight,
} from "lucide-react-native";
import { useRouter } from "expo-router";
import { format } from "date-fns";

const safeFormat = (value, pattern, fallback = "TBA") => {
  if (!value) return fallback;
  const d = new Date(value);
  if (isNaN(d.getTime())) return fallback;
  return format(d, pattern);
};

export default function FeedScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [selectedGenre, setSelectedGenre] = useState(null);

  const {
    data: events,
    isLoading,
    refetch,
  } = useQuery({
    queryKey: ["events", selectedGenre],
    queryFn: async () => {
      const url = selectedGenre
        ? `/api/events?genre=${selectedGenre}&upcoming=true`
        : "/api/events?upcoming=true";
      const response = await fetch(url);
      if (!response.ok) throw new Error("Network response was not ok");
      const data = await response.json();
      // Defensive: API can return {error: ...} on 200 in some error paths;
      // always hand the view a real array.
      return Array.isArray(data) ? data : [];
    },
  });

  const eventList = Array.isArray(events) ? events : [];
  const genres = ["Techno", "House", "Indie", "Hip-Hop", "Open Air", "Jazz"];

  return (
    <View style={{ flex: 1, backgroundColor: "#fff", paddingTop: insets.top }}>
      {/* Header */}
      <View
        style={{
          paddingHorizontal: 20,
          paddingVertical: 15,
          flexDirection: "row",
          justifyContent: "space-between",
          alignItems: "center",
        }}
      >
        <View>
          <Text style={{ fontSize: 28, fontWeight: "bold", color: "#000" }}>
            VieBe
          </Text>
          <Text style={{ fontSize: 14, color: "#666" }}>
            Wien's Events & Nightlife
          </Text>
        </View>
        <TouchableOpacity
          style={{ padding: 8, backgroundColor: "#F3F4F6", borderRadius: 20 }}
        >
          <Search size={20} color="#000" />
        </TouchableOpacity>
      </View>

      {/* Genre Filter */}
      <View style={{ height: 50, marginBottom: 10 }}>
        <ScrollView
          horizontal
          style={{ flexGrow: 0 }}
          showsHorizontalScrollIndicator={false}
          contentContainerStyle={{ paddingHorizontal: 20 }}
        >
          <TouchableOpacity
            onPress={() => setSelectedGenre(null)}
            style={{
              paddingHorizontal: 16,
              paddingVertical: 8,
              borderRadius: 20,
              backgroundColor: selectedGenre === null ? "#000" : "#F3F4F6",
              marginRight: 10,
              justifyContent: "center",
            }}
          >
            <Text
              style={{
                color: selectedGenre === null ? "#fff" : "#666",
                fontWeight: "600",
              }}
            >
              All
            </Text>
          </TouchableOpacity>
          {genres.map((genre) => (
            <TouchableOpacity
              key={genre}
              onPress={() => setSelectedGenre(genre)}
              style={{
                paddingHorizontal: 16,
                paddingVertical: 8,
                borderRadius: 20,
                backgroundColor: selectedGenre === genre ? "#000" : "#F3F4F6",
                marginRight: 10,
                justifyContent: "center",
              }}
            >
              <Text
                style={{
                  color: selectedGenre === genre ? "#fff" : "#666",
                  fontWeight: "600",
                }}
              >
                {genre}
              </Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{
          paddingHorizontal: 20,
          paddingBottom: insets.bottom + 80,
        }}
        refreshControl={
          <RefreshControl refreshing={isLoading} onRefresh={refetch} />
        }
      >
        <Text style={{ fontSize: 20, fontWeight: "bold", marginVertical: 15 }}>
          Tonight in Vienna
        </Text>

        {eventList.length === 0 && (
          <View style={{ padding: 40, alignItems: "center" }}>
            <Text style={{ color: "#666" }}>
              No events found for this category.
            </Text>
          </View>
        )}

        {eventList.map((event) => (
          <TouchableOpacity
            key={event.id}
            onPress={() => router.push(`/event/${event.id}`)}
            style={{
              backgroundColor: "#fff",
              borderRadius: 16,
              marginBottom: 20,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 2 },
              shadowOpacity: 0.1,
              shadowRadius: 4,
              elevation: 3,
              overflow: "hidden",
            }}
          >
            <Image
              source={{
                uri:
                  event.image_url ||
                  "https://images.unsplash.com/photo-1514525253361-bee8d41df740",
              }}
              style={{ width: "100%", height: 180 }}
            />
            <View style={{ padding: 15 }}>
              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "flex-start",
                }}
              >
                <View style={{ flex: 1 }}>
                  <Text
                    style={{
                      fontSize: 18,
                      fontWeight: "bold",
                      color: "#000",
                      marginBottom: 4,
                    }}
                  >
                    {event.title}
                  </Text>
                  <View
                    style={{
                      flexDirection: "row",
                      alignItems: "center",
                      marginBottom: 4,
                    }}
                  >
                    <MapPin size={14} color="#666" style={{ marginRight: 4 }} />
                    <Text style={{ fontSize: 14, color: "#666" }}>
                      {event.location_name || event.club_name}
                    </Text>
                  </View>
                </View>
                <View
                  style={{
                    backgroundColor: "#F3F4F6",
                    paddingHorizontal: 8,
                    paddingVertical: 4,
                    borderRadius: 8,
                  }}
                >
                  <Text
                    style={{ fontSize: 12, fontWeight: "600", color: "#000" }}
                  >
                    {event.genre}
                  </Text>
                </View>
              </View>

              <View
                style={{
                  flexDirection: "row",
                  justifyContent: "space-between",
                  alignItems: "center",
                  marginTop: 10,
                }}
              >
                <View style={{ flexDirection: "row", alignItems: "center" }}>
                  <CalendarIcon
                    size={14}
                    color="#666"
                    style={{ marginRight: 4 }}
                  />
                  <Text style={{ fontSize: 14, color: "#666" }}>
                    {safeFormat(event.start_time, "EEE, MMM d • HH:mm")}
                  </Text>
                </View>
                <Text
                  style={{ fontSize: 16, fontWeight: "700", color: "#000" }}
                >
                  {event.price === 0 ? "FREE" : `€${event.price}`}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        ))}
      </ScrollView>
    </View>
  );
}
