import React from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  StyleSheet,
  Share,
  Alert,
} from "react-native";
import * as Linking from "expo-linking";
import { useLocalSearchParams, useRouter } from "expo-router";
import { useQuery } from "@tanstack/react-query";
import { Image } from "expo-image";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import {
  ArrowLeft,
  MapPin,
  Calendar,
  Clock,
  Ticket,
  Share2,
  Heart,
  ExternalLink,
} from "lucide-react-native";
import { format } from "date-fns";
import MapView, { Marker } from "react-native-maps";

// Safely format a date that may be null/invalid. Returns fallback string if not parseable.
const safeFormat = (value, pattern, fallback = "TBA") => {
  if (!value) return fallback;
  const d = new Date(value);
  if (isNaN(d.getTime())) return fallback;
  return format(d, pattern);
};

export default function EventDetailsScreen() {
  const { id } = useLocalSearchParams();
  const router = useRouter();
  const insets = useSafeAreaInsets();

  const { data: event, isLoading } = useQuery({
    queryKey: ["event", id],
    queryFn: async () => {
      const response = await fetch(`/api/events?id=${id}`);
      if (!response.ok) throw new Error("Failed to fetch event");
      const events = await response.json();
      // API filters by id server-side; if it returned a list, take the first match.
      // Coerce both sides to string because useLocalSearchParams returns strings
      // but DB ids are numbers.
      if (!Array.isArray(events)) return null;
      return events.find((e) => String(e.id) === String(id)) ?? events[0] ?? null;
    },
  });

  const onShare = async () => {
    try {
      await Share.share({
        message: `Check out ${event.title} in Vienna on VieBe!`,
        url: event.ticket_url,
      });
    } catch (error) {
      console.error(error);
    }
  };

  if (isLoading || !event) {
    return (
      <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
        <Text>Loading event...</Text>
      </View>
    );
  }

  return (
    <View style={{ flex: 1, backgroundColor: "#fff" }}>
      <ScrollView
        style={{ flex: 1 }}
        contentContainerStyle={{ paddingBottom: insets.bottom + 100 }}
      >
        {/* Hero Image */}
        <View style={{ height: 400, width: "100%", position: "relative" }}>
          <Image
            source={{
              uri:
                event.image_url ||
                "https://images.unsplash.com/photo-1514525253361-bee8d41df740",
            }}
            style={{ width: "100%", height: "100%" }}
            contentFit="cover"
          />
          <TouchableOpacity
            onPress={() => router.back()}
            style={{
              position: "absolute",
              top: insets.top + 10,
              left: 20,
              backgroundColor: "rgba(255,255,255,0.8)",
              padding: 10,
              borderRadius: 25,
            }}
          >
            <ArrowLeft size={24} color="#000" />
          </TouchableOpacity>
        </View>

        {/* Content */}
        <View
          style={{
            padding: 20,
            marginTop: -30,
            backgroundColor: "#fff",
            borderTopLeftRadius: 30,
            borderTopRightRadius: 30,
          }}
        >
          <View
            style={{
              flexDirection: "row",
              justifyContent: "space-between",
              alignItems: "center",
              marginBottom: 10,
            }}
          >
            <View
              style={{
                backgroundColor: "#F3F4F6",
                paddingHorizontal: 10,
                paddingVertical: 5,
                borderRadius: 10,
              }}
            >
              <Text style={{ fontSize: 14, fontWeight: "600", color: "#666" }}>
                {event.genre}
              </Text>
            </View>
            <TouchableOpacity onPress={onShare}>
              <Share2 size={24} color="#000" />
            </TouchableOpacity>
          </View>

          <Text
            style={{
              fontSize: 28,
              fontWeight: "bold",
              color: "#000",
              marginBottom: 15,
            }}
          >
            {event.title}
          </Text>

          <View style={{ marginBottom: 20 }}>
            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <View
                style={{
                  backgroundColor: "#F3F4F6",
                  padding: 10,
                  borderRadius: 12,
                  marginRight: 15,
                }}
              >
                <Calendar size={20} color="#000" />
              </View>
              <View>
                <Text style={{ fontSize: 16, fontWeight: "600" }}>
                  {safeFormat(event.start_time, "EEEE, MMMM d", "Date TBA")}
                </Text>
                <Text style={{ fontSize: 14, color: "#666" }}>
                  {safeFormat(event.start_time, "HH:mm", "--:--")} onwards
                </Text>
              </View>
            </View>

            <View
              style={{
                flexDirection: "row",
                alignItems: "center",
                marginBottom: 12,
              }}
            >
              <View
                style={{
                  backgroundColor: "#F3F4F6",
                  padding: 10,
                  borderRadius: 12,
                  marginRight: 15,
                }}
              >
                <MapPin size={20} color="#000" />
              </View>
              <View>
                <Text style={{ fontSize: 16, fontWeight: "600" }}>
                  {event.location_name || event.club_name}
                </Text>
                <Text style={{ fontSize: 14, color: "#666" }}>
                  {event.club_address || "Vienna, Austria"}
                </Text>
              </View>
            </View>
          </View>

          <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 10 }}>
            About
          </Text>
          <Text
            style={{
              fontSize: 16,
              color: "#444",
              lineHeight: 24,
              marginBottom: 20,
            }}
          >
            {event.description ||
              "Join us for an unforgettable night in the heart of Vienna's club scene. Experience the best vibes and local talent."}
          </Text>

          {/* Map Preview */}
          <Text style={{ fontSize: 20, fontWeight: "bold", marginBottom: 10 }}>
            Location
          </Text>
          <View
            style={{
              height: 200,
              borderRadius: 16,
              overflow: "hidden",
              marginBottom: 20,
            }}
          >
            <MapView
              style={{ flex: 1 }}
              initialRegion={{
                latitude: event.latitude || 48.2082,
                longitude: event.longitude || 16.3738,
                latitudeDelta: 0.01,
                longitudeDelta: 0.01,
              }}
              scrollEnabled={false}
              zoomEnabled={false}
            >
              <Marker
                coordinate={{
                  latitude: event.latitude || 48.2082,
                  longitude: event.longitude || 16.3738,
                }}
                title={event.location_name}
              />
            </MapView>
          </View>
        </View>
      </ScrollView>

      {/* Footer Actions */}
      <View
        style={{
          position: "absolute",
          bottom: 0,
          left: 0,
          right: 0,
          backgroundColor: "#fff",
          paddingHorizontal: 20,
          paddingTop: 15,
          paddingBottom: insets.bottom + 10,
          borderTopWidth: 1,
          borderColor: "#eee",
          flexDirection: "row",
          alignItems: "center",
        }}
      >
        <TouchableOpacity
          style={{
            backgroundColor: "#F3F4F6",
            padding: 15,
            borderRadius: 16,
            marginRight: 10,
          }}
        >
          <Heart size={24} color="#000" />
        </TouchableOpacity>
        <TouchableOpacity
          onPress={async () => {
            if (!event.ticket_url) {
              Alert.alert("No tickets", "No ticket link available for this event yet.");
              return;
            }
            const supported = await Linking.canOpenURL(event.ticket_url);
            if (supported) {
              await Linking.openURL(event.ticket_url);
            } else {
              Alert.alert("Can't open link", "This link can't be opened on your device.");
            }
          }}
          style={{
            flex: 1,
            backgroundColor: "#000",
            padding: 18,
            borderRadius: 16,
            flexDirection: "row",
            justifyContent: "center",
            alignItems: "center",
          }}
        >
          <Ticket size={20} color="#fff" style={{ marginRight: 10 }} />
          <Text style={{ color: "#fff", fontSize: 18, fontWeight: "bold" }}>
            Get Tickets
          </Text>
        </TouchableOpacity>
      </View>
    </View>
  );
}
