-- Add external_id column for deduplication across scraper runs.
-- Run this ONCE in your database before using the new scraper.
-- If `events` is empty, it's zero risk. If you already have data,
-- existing rows will have NULL external_id which is fine.

ALTER TABLE events
  ADD COLUMN IF NOT EXISTS external_id TEXT;

-- Unique index so ON CONFLICT (external_id) works.
-- Partial index skips NULL rows (multiple NULLs allowed).
CREATE UNIQUE INDEX IF NOT EXISTS events_external_id_unique
  ON events (external_id)
  WHERE external_id IS NOT NULL;
