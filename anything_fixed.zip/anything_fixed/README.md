# VieBe — aplikacja eventowa dla Wiednia

Twoja apka z wbudowanymi poprawkami i integracją Ticketmastera.

## Co jest w środku

```
apps/
├── mobile/        ← aplikacja Expo/React Native (iOS + Android + web)
└── web/           ← backend Next.js (API, auth, Stripe, scraper eventów)
```

## Co zostało zmienione względem oryginału

### Mobile app — poprawki krytycznych bugów

| Plik | Co naprawiono |
|---|---|
| `apps/mobile/src/app/_layout.jsx` | Dodany `<AuthModal />` do drzewa — bez tego logowanie w ogóle nie działało |
| `apps/mobile/src/app/(tabs)/index.jsx` | Feed nie crashuje na pustych datach + obsługa błędów API |
| `apps/mobile/src/app/(tabs)/map.jsx` | Mapa nie crashuje gdy API zwraca błąd |
| `apps/mobile/src/app/event/[id].jsx` | Szczegóły eventu się ładują (bug z typami id) + "Get Tickets" otwiera link |
| `apps/mobile/src/app/stripe.jsx` | Guard na zablokowany popup |
| `apps/mobile/src/utils/auth/*` | Logowanie działa, wylogowanie wylogowuje naprawdę |
| `apps/mobile/src/utils/use-subscription.js` | Status subskrypcji nie skipuje kolejnych wywołań |

### Backend — Ticketmaster

- `apps/web/src/app/api/scrape-events/route.js` — **nowa implementacja** pobiera realne eventy z Ticketmastera (109 dla Wiednia), zamiast zwracać placeholdery

## Zanim to odpalisz

### 1. Zainstaluj zależności

W terminalu, z katalogu głównego projektu:

```bash
cd apps/mobile && npm install
cd ../web && npm install
```

### 2. Dodaj klucz Ticketmastera

W pliku `apps/web/.env` dodaj linię:

```
TICKETMASTER_API_KEY=twoj_klucz_tutaj
```

### 3. Odpal migrację SQL w bazie

Plik `migration-add-external-id.sql` (w tym katalogu). Uruchom w panelu bazy danych Anything / Neon:

```sql
ALTER TABLE events
  ADD COLUMN IF NOT EXISTS external_id TEXT;

CREATE UNIQUE INDEX IF NOT EXISTS events_external_id_unique
  ON events (external_id)
  WHERE external_id IS NOT NULL;
```

### 4. Uzupełnij puste klucze w `.env` (opcjonalne)

W `apps/mobile/.env`:
- `EXPO_PUBLIC_GOOGLE_MAPS_API_KEY=` — bez tego mapa na webie nie wczyta
- `EXPO_PUBLIC_UPLOADCARE_PUBLIC_KEY=` — bez tego upload plików rzuci błąd

Nie są krytyczne na start.

## Jak odpalić

### Mobile (Expo)

```bash
cd apps/mobile
npx expo start
```

Zeskanujesz QR kod aplikacją Expo Go na telefonie — apka uruchomi się na telefonie.

### Backend (web)

```bash
cd apps/web
npm run dev
```

### Zaciąganie eventów

Po uruchomieniu backendu, wywołaj (z terminala, Postmana, przeglądarki):

```bash
curl -X POST http://localhost:3000/api/scrape-events
```

Dostaniesz odpowiedź w stylu `{"success": true, "scraped": 109, "inserted": 109}`. Od teraz feed w apce pokaże realne eventy.

## Co jeszcze do zrobienia (nie pilne)

- Friends tab używa mock data — trzeba podpiąć do API
- Cron scheduler żeby `/api/scrape-events` się sam odpalał co 6h
- Eventbrite jako drugie źródło eventów (dla mniejszych imprez)
- Mapbox zamiast Google Maps (tańszy, lepszy dark mode)

## Pomoc

Jeśli coś nie działa — wróć do Claude'a z:
1. Dokładnym komunikatem błędu (screen albo tekst)
2. Krokiem na którym utknąłeś
